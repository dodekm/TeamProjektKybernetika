vstup = [0 1 2 3 4 5]
vystup = [0 0.05 0.1 0.15 0.2 0.25]

plot(vstup, vystup)
xlabel("vstup")
ylabel("vystup")
title("prevodova charakteristika")