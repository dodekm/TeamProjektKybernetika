x = 1 + 1i
xreal = real(x) %zistenie realnej zlozky
ximag = imag(x) %zistenie imaginarnej zlozky
xk = conj(x)    %vytvorenie komplexne zdruzeneho cisla

z = abs(x)      %velkost komplexneho cisla
phi = angle(x)  %uhol komplexneho cisla